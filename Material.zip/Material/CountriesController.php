<?php

namespace App\Http\Controllers\Admin;
use App\Countries;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Datatables;
use Input;
use App\Partners;
use App\Experts;
use App\General;





class CountriesController extends Controller
{

    /**
	* Getting listing for countries management
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*@param Object Request 
	*/	
    public function index(Request $request)
	{

		return view('administrator.countries.list');
	}
    
	/**
	 * Process datatables ajax request.
	 *
	 * @return \Illuminate\Http\JsonResponse
	*/
    public function anyData()
    {
    	DB::statement(DB::raw('set @rownum=0'));
        $countries = DB::table('countries')
            ->leftJoin('users as user', 'countries.created_by', '=', 'user.id')
            ->select(DB::raw('@rownum  := @rownum  + 1 AS rownum'),'countries.*','user.name as added_user_name')
			
            ->get();
         return Datatables::of($countries)
            ->addColumn('action', function ($countries) {
                return '<div class="btn-group"><button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></button><ul class="dropdown-menu" role="menu"><li><a title="'.trans('message.Edit').'"  href="/admin/countries/edit/'.$countries->country_id.'" >'.trans('message.Edit').'</a></li><li><a title="'.trans('message.Delete').'"  href="/admin/countries/delete/'.$countries->country_id.'" onclick="return(confirm("'.trans('notify.delete_confirm').'"))">'.trans('message.Delete').'</a></li></ul></div>';
            })
            ->editColumn('id', 'ID: {{$country_id}}')
			->make(true);
    }

	/**
	* Create countries and redirected after submitting to updateadd
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*
	*/
	public function create(){
		return view('administrator.countries.create');
	}


	/**
	* Edit currency and redirected after submitting to updateadd using id
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*@param Object Request
	*@param $currency_id
	*/
	public function edit(Request $request){
		$getall_data = Countries::find($request->countries_id);
		return view('administrator.countries.create', ['countries_data'=>$getall_data]);
	}


	/**
	* Add and updating currency
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*@param Object Request
	*@param $currency_id
	*/
	public function updateadd(Request $request){

        $messages = array(
		    'name.required' => trans("notify.error_mandatory"),
		    'name.regex' => trans("notify.error_country_max_min_aplha"),
		    'name.max' => trans("notify.error_country_max_min_aplha"),
		    'name.min' => trans("notify.error_country_max_min_aplha"),
		    'iso_code_2.alpha' => trans("notify.error_iso2_aplha"),
		    'iso_code_2.max' => trans("notify.error_iso2_aplha"),
		    'iso_code_2.min' => trans("notify.error_iso2_aplha"),
		    'iso_code_3.alpha' => trans("notify.error_iso3_aplha"),
		    'iso_code_3.max' => trans("notify.error_iso3_aplha"),
		    'iso_code_3.min' => trans("notify.error_iso3_aplha"),
		);
		$valid = Validator::make(Input::all(), [
                    'name' => 'required|min:3|regex:/^[a-zA-Z][a-zA-Z.& ]+$/|max:128',
                    'iso_code_2' => 'alpha|max:2|min:2',
                    'iso_code_3' => 'alpha|max:3|min:3',
        ],$messages);

		if($valid->fails()) {
			$countries_id = Input::get('countries_id');
			if ($countries_id != '')
				$redirectURL = '/admin/countries/edit/'.$countries_id;
			else
               $redirectURL = '/admin/countries/create';
            return redirect($redirectURL)
                        ->withErrors($valid)
                        ->withInput();
        }else{
        	$countries_id = $request->input('countries_id');
        	$countries = new Countries;
            if ($countries_id != '') {
            	$countries = Countries::find($request->input('countries_id'));
            	$countries->name = $request->input('name');
            	$countries->iso_code_2 = $request->input('iso_code_2');
	        	$countries->iso_code_3 = $request->input('iso_code_3');
				$countries->status = 1;
            	$countries->updated_at = date('Y-m-d H:i:s');
            	$countries->updated_by = Auth::user()->id;
            	$countries->save();
                $request->session()->flash('alert-success', trans('message.updated_success'));			
				return redirect('/admin/countries');
            } else {
	        	$countries->name = $request->input('name');
            	$countries->iso_code_2 = $request->input('iso_code_2');
	        	$countries->iso_code_3 = $request->input('iso_code_3');
				$countries->status = 1;
	        	$countries->created_at = date('Y-m-d H:i:s');
				$countries->created_by = Auth::user()->id;
				$countries->updated_by = 0;
				$countries->save();	
				$request->session()->flash('alert-success', trans('message.added_success'));			
				return redirect('/admin/countries');
			}
        }
	}
	

	/**
	* Remove a country
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*@param Object Request 
	*/	
	public function remove(Request $request)
	{
		
		$partners_count = Partners::where(['country_reg' => $request->countries_id])->orwhere(['company_location' => $request->countries_id])->orwhereRaw('FIND_IN_SET('.$request->countries_id.',country_exp)')->get()->count();
		$expert_count = Experts::where(['nationality' => $request->countries_id])->orwhereRaw('FIND_IN_SET('.$request->countries_id.',country_exp)')->get()->count();
		$general_count = General::where(['nationality' => $request->countries_id])->get()->count();
		if($partners_count > 0 || $expert_count > 0 || $general_count > 0 )
		{
			$request->session()->flash('alert-danger', 'Sorry ! This Country is used in various Records');
		}
		else{
			try {
				 Countries::where(['country_id' => $request->countries_id])->delete();
				$request->session()->flash('alert-success', trans('message.deleted_success'));
			}catch(\Exception $e){
				$request->session()->flash('alert-warning', $e->getMessage());
			}
		}
		 return redirect('/admin/countries');		
		
	}
	
	
}
