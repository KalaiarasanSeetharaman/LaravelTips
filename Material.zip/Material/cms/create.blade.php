@extends('layouts.admin.app')

@section('htmlheader_title', 'Cms')

@section('menu', 'Pages')
<?php if(isset($cms_data['id'])){ ?>

    @section('contentheader_title', 'Update Page')

<?php }else{ ?>

    @section('contentheader_title', 'Add Page')

<?php } ?>

@section('list_link')
<li><a href="<?= url('/admin/cms') ?>">{{ trans('message.cms') }}</a></li>
@endsection

@section('main-content')

<div class="box box-default">
{!! Form::open(['url' => '/admin/cms/updateadd', 'method'=>'post', 'enctype' => 'multipart/form-data']) !!}
{{ csrf_field() }}
    <div class="box-body">
        <div class="row">
            <div class="col-md-12">All fields marked with <span class='required'>*</span>  are Mandatory</span></div><br><br>
            <div class="col-md-12">
                <div class="pull-right">
                    <button type="submit" title="{{ trans('message.Save') }}" class="btn btn-primary">
                    {{ trans('message.Save') }}
                    </button>
                    <!-- <button type="reset" id="reset" title="{{ trans('message.reset') }}" class="btn btn-primary">
                    {{ trans('message.reset') }}
                    </button> -->
                    <a href="<?= url('/admin/cms') ?>" title="{{ trans('message.reset') }}" class="btn btn-primary">{{ trans('message.reset') }}</a>
                </div>
            </div>
            <div class="col-md-8">
                 <input type="hidden" name="cms_id" value="<?php if(isset($cms_data['id'])){ echo $cms_data['id']; }else{echo ""; }?>"> 
                <div class="form-group" >
                    {!! Form::label('name', trans('message.page_title'),['for' => trans('message.page_title'), 'class' => 'control-label',  'data-toggle'=>'tooltip', 'data-html'=>'true', 'data-original-title'=>'Invalid characters:
                    <>;=#{}']) !!}<span class="required">*</span>
                    {!! Form::select('page_title', $page,old('page_title',  isset($cms_data['page_title']) ? $cms_data['page_title'] : null) , ['class' => 'form-control', 'maxlength'=>'20' ,'placeholder' =>trans('message.page_title'), 'autofocus'=>true]) !!} 
                    @if ($errors->has('page_title'))
                        <span class="help-block {{ $errors->has('page_title') ? ' has-error' : '' }}">
                            <strong>{{ $errors->first('page_title') }}</strong>
                        </span>
                    @endif               
                </div>
                <div class="form-group" >
                    {!! Form::label('description_content', trans('message.description_content'),['for' => trans('message.description_content'), 'class' => 'control-label' , 'data-toggle'=>'tooltip', 'data-html'=>'true', 'data-original-title'=>'Invalid characters:<>;=#{}']) !!}<span class="required">*</span>
                    {!! Form::textarea('description', old('description',  isset($cms_data['description']) ? $cms_data['description'] : null) , ['class' => 'form-control description_content', 'placeholder' =>trans('message.description_content'), 'id' => 'description' ,'autofocus'=>true]) !!} 
                    @if ($errors->has('description'))
                        <span class="help-block {{ $errors->has('description') ? ' has-error' : '' }}">
                            <strong>{{ $errors->first('description') }}</strong>
                        </span>
                    @endif               
                </div>
                <div class="form-group" >
                    {!! Form::label('meta_description', trans('message.meta_description'),['for' => trans('message.meta_description'), 'class' => 'control-label']) !!}
                    {!! Form::text('meta_description', old('meta_description',  isset($cms_data['meta_description']) ? $cms_data['meta_description'] : null) , ['class' => 'form-control', 'placeholder' =>trans('message.meta_description'), 'autofocus'=>true]) !!} 
                    @if ($errors->has('meta_description'))
                        <span class="help-block {{ $errors->has('meta_description') ? ' has-error' : '' }}">
                            <strong>{{ $errors->first('meta_description') }}</strong>
                        </span>
                    @endif               
                </div>
                <div class="form-group" >
                    {!! Form::label('meta_keywords', trans('message.meta_keywords'),['for' => trans('message.meta_keywords'), 'class' => 'control-label','data-toggle'=>'tooltip', 'data-html'=>'true', 'data-original-title'=>'To add &quot;tags&quot; click in the field, write something, and then press &quot;Comma.&quot;']) !!}
                    <br>
                    {!! Form::text('meta_keyword', old('meta_keyword',  isset($cms_data['meta_keyword']) ? $cms_data['meta_keyword'] : null) , ['class' => 'form-control meta_keywords multi_tags', 'data-role'=>'tagsinput', 'placeholder' =>trans('message.meta_keywords'), 'autofocus'=>true]) !!} 
                    @if ($errors->has('meta_keywords'))
                        <span class="help-block {{ $errors->has('meta_keywords') ? ' has-error' : '' }}">
                            <strong>{{ $errors->first('meta_keywords') }}</strong>
                        </span>
                    @endif               
                </div>
                <div class="form-group" >
                        {!! Form::label('spacing', trans('message.status'),['for' => trans('message.status'), 'class' => 'control-label']) !!}
                        <?php isset($cms_data['id'])? ($old['status'] = $cms_data['status']): ($old['status'] = Input::old('status')) ; ?>
                        <input type="checkbox" data="<?php echo $old['status']; ?>" state="true" name="status" class="swtich" id="dimension-switch" <?php if($old['status'] == '0' || $old['status'] == 'on'){ echo ""; }else{ echo "checked"; } ?> data-toggle="toggle"  data-on-text="Yes" data-off-text="No" >
                </div>
            </div>
        </div>
        <br>
        <!-- /.col -->
        <div class="box-footer">
            <div class="row">
                <div class="col-md-12">
                    <div class="pull-right">
                        <button type="submit" title="{{ trans('message.Save') }}" class="btn btn-primary">
                                {{ trans('message.Save') }}
                         </button>
                         <!-- <button type="reset" id="reset" title="{{ trans('message.reset') }}" class="btn btn-primary">
                                {{ trans('message.reset') }}
                         </button> -->
                         <a href="<?= url('/admin/cms') ?>" title="{{ trans('message.reset') }}" class="btn btn-primary">{{ trans('message.reset') }}</a>
                    </div>
                </div>
             </div>
        </div>
    </div>
{{ Form::close() }}     
</div>
<script type="text/javascript">
    CKEDITOR.replace('description');
    $('#reset').on('click',function(){
         CKupdate();
    });
    function CKupdate(){
        for ( instance in CKEDITOR.instances ){
            CKEDITOR.instances[instance].updateElement();
            CKEDITOR.instances[instance].setData('');
        }
    }
</script>
@endsection
