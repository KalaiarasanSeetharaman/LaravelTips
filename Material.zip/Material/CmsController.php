<?php

namespace App\Http\Controllers\Admin;
use App\Cms;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Datatables;
use Input;
use App\Funds;
use App\Permission;




class CmsController extends Controller
{
	private $page;
    /**
	* Getting listing for currency management
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*@param Object Request 
	*/	
	public function __construct()
	{
		$this->page = array('page_abt'=>'About Asian NGO','page_cont'=>'Contact Us','page_advert'=>'Advertise with us','page_pp'=>'Privacy Policy','page_faq'=>'FAQ','page_disc'=>'Disclaimer','page_cookie'=>'Cookie Policy','page_agree'=>'User Agreement','page_refund_cancelation'=>'Refund & Cancelation Policy','page_purchase_policy'=>'Purchase Policy');
	}
    public function index(Request $request)
	{

		return view('administrator.cms.list');
	}
    
	/**
	 * Process datatables ajax request.
	 *
	 * @return \Illuminate\Http\JsonResponse
	*/
    public function anyData()
    {
    	DB::statement(DB::raw('set @rownum=0'));
        $cmss = DB::table('cms')
            ->leftJoin('users as user', 'cms.created_by', '=', 'user.id')
            ->select(DB::raw('@rownum  := @rownum  + 1 AS rownum'),'cms.*','user.name as added_user_name')
            ->get();
         return Datatables::of($cmss)
            ->addColumn('action', function ($cmss) {
			 $action_data = '';
			 $action_data .= '<div class="btn-group"><button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></button><ul class="dropdown-menu" role="menu">';	
			  if($this->permission('cms-edit')==1){
                    $action_data .= '<li><a title="'.trans('message.Edit').'"  href="/admin/cms/edit/'.$cmss->id.'" >'.trans('message.Edit').'</a></li>';
               }
			   if($this->permission('cms-delete')==1){
                    $action_data .= '<li><a title="'.trans('message.Delete').'"  href="/admin/cms/delete/'.$cmss->id.'" class="delete_confirm">'.trans('message.Delete').'</a></li>';
               }
			    $action_data .= '</ul></div>';
                return $action_data;
               // return '<div class="btn-group"><button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></button><ul class="dropdown-menu" role="menu"><li><a title="'.trans('message.Edit').'"  href="/admin/cms/edit/'.$cmss->id.'" >'.trans('message.Edit').'</a></li><li><a title="'.trans('message.Delete').'"  href="/admin/cms/delete/'.$cmss->id.'" class="delete_confirm">'.trans('message.Delete').'</a></li></ul></div>';
            })
			->editColumn('page_title',function ($cmss) {
					$title = $this->page[$cmss->page_title];
			return $title;
			})
            ->editColumn('status', '@if($status == "0") Deactive @elseif($status == "1") Active  @endif')
            ->editColumn('id', 'ID: {{$id}}')
            ->make(true);
    }
 
	public function permission($rule_permission_name){
        $getpermission = DB::table('role_user')
            ->leftJoin('permission_role', 'role_user.role_id', '=', 'permission_role.role_id')
            ->leftJoin('permissions', 'permission_role.permission_id', '=', 'permissions.id')
            ->where('permissions.name','=',$rule_permission_name)
            ->where('role_user.user_id','=',Auth::user()->id)
            ->get()->count();
      return  $getpermission;
            exit;
    }

	/**
	* Create cms and redirected after submitting to updateadd
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*
	*/
	public function create(){
		return view('administrator.cms.create',['page'=>$this->page]);
	}


	/**
	* Edit currency and redirected after submitting to updateadd using id
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*@param Object Request
	*@param $cms_id
	*/
	public function edit(Request $request){
		$getall_data = Cms::find($request->cms_id);
		return view('administrator.cms.create', ['cms_data'=>$getall_data,'page'=>$this->page]);
	}


	/**
	* Add and updating cms
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*@param Object Request
	*@param $cms_id
	*/
	public function updateadd(Request $request){
       
        $messages = array(
		    'page_title.required'  => trans("notify.error_mandatory"),
		    'description.required' => trans("notify.error_mandatory"),
		    'page_title.max'       => trans("notify.error_page_title_min_max"),
		    'page_title.min'       => trans("notify.error_page_title_min_max"),
		    'page_title.regex'	   => trans("notify.error_page_title_min_max"), 
		);
		$valid = Validator::make(Input::all(), [
                    'page_title' => 'required|unique:cms,page_title,'.$request->cms_id,
                    'description' => 'required',
        ],$messages);

		if($valid->fails()) {
			$cms_id = Input::get('cms_id');
			if ($cms_id != '')
				$redirectURL = '/admin/cms/edit/'.$cms_id;
			else
               $redirectURL = '/admin/cms/create';
            return redirect($redirectURL)
                        ->withErrors($valid)
                        ->withInput();
        }else{
        	$status = 0;
        	if(isset($_REQUEST['status']))
        		$status = 1;
        	$cms_id = $request->input('cms_id');
        	$cms = new Cms;
            if ($cms_id != '') {
            	$cms = Cms::find($request->input('cms_id'));
            	$cms->page_title = $request->input('page_title');
            	$cms->description = $request->input('description');
	        	$cms->meta_keyword = $request->input('meta_keyword');
	        	$cms->meta_description = $request->input('meta_description');
	        	$cms->status = $status;
            	$cms->updated_at = date('Y-m-d H:i:s');
            	$cms->updated_by = Auth::user()->id;
            	$cms->save();
                $request->session()->flash('alert-success', trans('message.updated_success'));			
				return redirect('/admin/cms');
            } else {
	        	$cms->page_title = $request->input('page_title');
            	$cms->description = $request->input('description');
	        	$cms->meta_keyword = $request->input('meta_keyword');
	        	$cms->meta_description = $request->input('meta_description');
	        	$cms->status = $status;
            	$cms->created_at = date('Y-m-d H:i:s');
            	$cms->created_by = Auth::user()->id;
            	$cms->remember_token = Str::quickRandom(16);
				$cms->updated_by = 0;
				$cms->save();	
				$request->session()->flash('alert-success', trans('message.added_success'));			
				return redirect('/admin/cms');
			}
        }
	}
	

	/**
	* Remove a thematicarea information from thematicarae Table
	*
	*@author Kalai<kalaiarasan.s@shloklabs.com>
	*@param Object Request 
	*/	
	public function remove(Request $request)
	{
		try {
				Cms::where(['id' => $request->cms_id])->delete();
				$request->session()->flash('alert-success', trans('message.deleted_success'));
			}catch(\Exception $e){
				$request->session()->flash('alert-warning', $e->getMessage());
			}
		
		 return redirect('/admin/cms');		
		
	}
	
	
}
