@extends('layouts.admin.app')

@section('htmlheader_title', 'Country List')

@section('menu', 'Country List')

@section('contentheader_title', 'Country List')


@section('main-content')
	<div class="row">
        <div class="col-xs-12">
          <!-- /.box-header -->
          <div class="box">
            <br>
            <div class="box-header row">
          		<div class="col-xs-2 col-md-2 pull-right"><a title="{{ trans('message.Add New') }}" href="{{ url('/admin/countries/create')}}" class="btn btn-block btn-primary pull-right">{{ trans('message.Add New') }}</a></div>
            </div>
            <br>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
              <table id="countries_listing_table" class="table  table-striped countries_listing_table">
                <thead>
                  <tr>
        					 <!-- <th>{{ trans('message.S.No') }}</th> -->
        					 <th>{{ trans('message.Name') }}</th>
        					 <th>{{ trans('message.iso_code_2') }}</th>
        					 <th>{{ trans('message.iso_code_3') }}</th>
        					 <th>{{ trans('message.Added by') }}</th>
        					 <th>{{ trans('message.Created date') }}</th>
        				 	<th>{{ trans('message.Action') }}</th>
        			 	</tr>
                </thead>
              </table>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
 <!-- /.row -->
@endsection
@push('scripts')
<script>
$(function() {
    $('#countries_listing_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ url('/admin/countries/data')}}",
		    order: [[ 4, "desc" ]],
        columns: [
            /*{data: 'rownum', name: 'rownum'},*/
            { data: 'name', name: 'name' },
            { data: 'iso_code_2', name: 'iso_code_2' },
            { data: 'iso_code_3', name: 'iso_code_3' },
            { data: 'added_user_name', name: 'added_user_name' },
            { data: 'created_at', name: 'created_at' },
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
});
</script>
@endpush
