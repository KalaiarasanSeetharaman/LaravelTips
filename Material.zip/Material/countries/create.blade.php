@extends('layouts.admin.app')

@section('htmlheader_title', 'Countries')

@section('menu', 'Countries')

<?php if(isset($countries_data['country_id'])){?>
    @section('contentheader_title', 'Update Country')
<?php }else{ ?>
    @section('contentheader_title', 'Add Country')
<?php } ?>

@section('list_link')
<li><a href="<?= url('/admin/countries') ?>">{{ trans('message.countries_list') }}</a></li>
@endsection

@section('main-content')

<div class="box box-default">
{!! Form::open(['url' => '/admin/countries/updateadd', 'method'=>'post', 'enctype' => 'multipart/form-data']) !!}
{{ csrf_field() }}
    <div class="box-body">
        <div class="row">
            <div class="col-md-12">All fields marked with <span class='required'>*</span>  are Mandatory</span></div><br><br>
            <div class="col-md-8">
                 <input type="hidden" name="countries_id" value="<?php if(isset($countries_data['country_id'])){ echo $countries_data['country_id']; }else{echo ""; }?>"> 
                <div class="form-group" >
                    {!! Form::label('name', trans('message.country_name'),['for' => trans('message.country_name'), 'class' => 'control-label']) !!}<span class="required">*</span>
                    {!! Form::text('name', old('name',  isset($countries_data['name']) ? $countries_data['name'] : null) , ['class' => 'form-control', 'maxlength'=>'128' ,'placeholder' =>trans('message.country_name'), 'autofocus'=>true]) !!} 
                    @if ($errors->has('name'))
                        <span class="help-block {{ $errors->has('name') ? ' has-error' : '' }}">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
                    @endif               
                </div>
                <div class="form-group" >
                    {!! Form::label('iso_code_2', trans('message.iso_code_2'),['for' => trans('message.iso_code_2'), 'class' => 'control-label']) !!}
                    {!! Form::text('iso_code_2', old('iso_code_2',  isset($countries_data['iso_code_2']) ? $countries_data['iso_code_2'] : null) , ['class' => 'form-control', 'maxlength'=>'2' ,'placeholder' =>trans('message.iso_code_2'), 'autofocus'=>true]) !!} 
                    @if ($errors->has('iso_code_2'))
                        <span class="help-block {{ $errors->has('iso_code_2') ? ' has-error' : '' }}">
                            <strong>{{ $errors->first('iso_code_2') }}</strong>
                        </span>
                    @endif               
                </div>
                <div class="form-group" >
                    {!! Form::label('iso_code_3', trans('message.iso_code_3'),['for' => trans('message.iso_code_3'), 'class' => 'control-label']) !!}
                    {!! Form::text('iso_code_3', old('iso_code_3',  isset($countries_data['iso_code_3']) ? $countries_data['iso_code_3'] : null) , ['class' => 'form-control', 'maxlength'=>'3' ,'placeholder' =>trans('message.iso_code_3'), 'autofocus'=>true]) !!} 
                    @if ($errors->has('iso_code_3'))
                        <span class="help-block {{ $errors->has('iso_code_3') ? ' has-error' : '' }}">
                            <strong>{{ $errors->first('iso_code_3') }}</strong>
                        </span>
                    @endif               
                </div>
                <?php
                /*
                <div class="form-group" >
                        {!! Form::label('status', trans('message.status'),['for' => trans('message.status'), 'class' => 'control-label']) !!}
                        <?php isset($countries_data['country_id'])? ($old['status'] = $countries_data['status']): ($old['status'] = Input::old('status')) ; ?>  
                        <input type="checkbox" data="<?php echo $old['status']; ?>" state="true" name="status" class="swtich" id="dimension-switch" <?php if($old['status'] == '0' || $old['status'] == 'on'){ echo ""; }else{ echo "checked"; } ?> data-toggle="toggle"  data-on-text="Yes" data-off-text="No" >
                </div>
                */
                ?>
            </div>
        </div>
        <br>
        <!-- /.col -->
        <div class="box-footer">
            <div class="row">
                <div class="col-md-12">
                    <div class="pull-right">
                        <button type="submit" title="{{ trans('message.Save') }}" class="btn btn-primary">
                                {{ trans('message.Save') }}
                         </button>
                         <!-- <button type="reset" id="reset" title="{{ trans('message.reset') }}" class="btn btn-primary">
                                {{ trans('message.reset') }}
                         </button> -->
                         <a href="<?= url('/admin/countries') ?>" title="{{ trans('message.reset') }}" class="btn btn-primary">{{ trans('message.reset') }}</a>
                    </div>
                </div>
             </div>
        </div>
    </div>
{{ Form::close() }}     
</div>
@endsection
